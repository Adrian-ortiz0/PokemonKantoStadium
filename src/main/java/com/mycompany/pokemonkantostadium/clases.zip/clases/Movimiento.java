/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pokemonkantostadium.clases;

/**
 *
 * @author Danie
 */
public class Movimiento {
    
    private String nombre;
    private int pp;
    private Tipo tipo;

    public Movimiento(String nombre, int pp, Tipo tipo) {
        this.nombre = nombre;
        this.pp = pp;
        this.tipo = tipo;
    }
    
    public void reducirPp() {
        if (pp > 0) {
            pp--;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPp() {
        return pp;
    }

    public void setPp(int pp) {
        this.pp = pp;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }
    
        
}
